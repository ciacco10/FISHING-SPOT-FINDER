<?php
//--Qui va inserita l'API Key personale di OpenWeather
define('OPENWEATHER_API_KEY', '464b92bb014452011676566fa488e920');
?>

